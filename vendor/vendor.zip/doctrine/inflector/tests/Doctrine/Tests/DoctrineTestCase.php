<?php

namespace Doctrine\Tests;

/**
 * Base testcase class for all Doctrine testcases.
 */
abstract class DoctrineTestCase extends \PHPUnit_Framework_TestCase
{
}