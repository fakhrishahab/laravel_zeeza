<?php

namespace App\Http\Models;

use DB;
use Illuminate\Database\Eloquent\Model;

class users extends Model{
	protected $table = "users";
}