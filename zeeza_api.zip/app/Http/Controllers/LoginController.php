<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use App;
use URL;
use Config;
use Curl;
use Response;
use App\Http\Models\users;
use App\Http\Controllers\Auth\CurlController;


class LoginController extends Controller
{
    // function __construct(){
    // 	$this->data = new Users();
    // }

    function login(Request $request){
        $credentials = [
            'client_id' => Config::get('constant.CLIENT_ID'),
            'client_secret' => Config::get('constant.CLIENT_SECRET'),
            'grant_type' => $request->grant_type,
            'username' => $request->username,
            'password' => $request->password
        ];

    	$get_user = DB::table('users')
    				->where('email', $request->username)
    				->get();

    	if($get_user){
    		if(sha1($request->password) != $get_user[0]->password){
    			return Response::json('not found' ,404);
    		}else{
            //     Curl::post($url,
            //     array(), // array yang pertama ini untuk get
            //     array(  
            //         'client_id' => $client_id, // array yang kedua ini untuk method post
            //         'client_secret' => $client_secret,
            //         'grant_type' => $grant_type
            //     )
            // );

                return Curl::post('http://api.zeezabutik.com/oauth/access_token',
                        array(),
                        $credentials
                    );


                // $curlService = new \Ixudra\Curl\CurlService();
                // $response = Curl::to('http://api.zeezabutik.com/oauth/access_token')
                //             ->withData($credentials)
                //             ->get();
                // return Curl;
    			// return App::make('App\Http\Controllers\Auth\CurlController')->proxy($request, $get_user);
    		}
    	}else{
    		echo 'ga ada';
    	}
    }
}
