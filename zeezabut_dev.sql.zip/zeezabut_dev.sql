-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Feb 23, 2016 at 09:28 AM
-- Server version: 5.6.26-cll-lve
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zeezabut_dev`
--

-- --------------------------------------------------------

--
-- Table structure for table `age`
--

CREATE TABLE IF NOT EXISTS `age` (
  `id_age` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_age`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `age`
--

INSERT INTO `age` (`id_age`, `name`) VALUES
(1, '0 - 1 Tahun'),
(2, '1 - 3 Tahun'),
(3, '3 - 5 Tahun'),
(4, '> 5 Tahun');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id_category` int(11) NOT NULL,
  `rank` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_category`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id_category`, `rank`, `name`) VALUES
(1, 1, 'baby girl'),
(2, 2, 'baby boy'),
(3, 3, 'girl''s room'),
(4, 4, 'boy''s room');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `name`) VALUES
(1, 'head menu'),
(2, 'contact menu'),
(3, 'brand menu'),
(4, 'footer menu'),
(5, 'flash news');

-- --------------------------------------------------------

--
-- Table structure for table `menu_content`
--

CREATE TABLE IF NOT EXISTS `menu_content` (
  `id` int(11) NOT NULL,
  `menu` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_content`
--

INSERT INTO `menu_content` (`id`, `menu`, `name`, `content`) VALUES
(1, 1, 'Cara Pemesanan', 'Ini Cara Pemesanan'),
(2, 1, 'Daftar Reseller', 'Ini Daftar Reseller'),
(3, 1, 'Sahabat Zeeza', 'Sahabat Zeeza'),
(4, 1, 'FAQ', 'ini FAQ'),
(5, 2, 'whatsapp', '085720123245'),
(6, 2, 'bbm', '5294878a'),
(7, 2, 'line', 'zeezabutik'),
(8, 2, 'instagram', '@Zeeza_butik'),
(11, 2, 'bbm', '7D938756');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_04_24_110151_create_oauth_scopes_table', 1),
('2014_04_24_110304_create_oauth_grants_table', 1),
('2014_04_24_110403_create_oauth_grant_scopes_table', 1),
('2014_04_24_110459_create_oauth_clients_table', 1),
('2014_04_24_110557_create_oauth_client_endpoints_table', 1),
('2014_04_24_110705_create_oauth_client_scopes_table', 1),
('2014_04_24_110817_create_oauth_client_grants_table', 1),
('2014_04_24_111002_create_oauth_sessions_table', 1),
('2014_04_24_111109_create_oauth_session_scopes_table', 1),
('2014_04_24_111254_create_oauth_auth_codes_table', 1),
('2014_04_24_111403_create_oauth_auth_code_scopes_table', 1),
('2014_04_24_111518_create_oauth_access_tokens_table', 1),
('2014_04_24_111657_create_oauth_access_token_scopes_table', 1),
('2014_04_24_111810_create_oauth_refresh_tokens_table', 1),
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE IF NOT EXISTS `oauth_access_tokens` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `session_id` int(10) unsigned NOT NULL,
  `expire_time` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `oauth_access_tokens_id_session_id_unique` (`id`,`session_id`),
  KEY `oauth_access_tokens_session_id_index` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_token_scopes`
--

CREATE TABLE IF NOT EXISTS `oauth_access_token_scopes` (
  `id` int(10) unsigned NOT NULL,
  `access_token_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `scope_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_token_scopes_access_token_id_index` (`access_token_id`),
  KEY `oauth_access_token_scopes_scope_id_index` (`scope_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE IF NOT EXISTS `oauth_auth_codes` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `session_id` int(10) unsigned NOT NULL,
  `redirect_uri` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `expire_time` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_session_id_index` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_code_scopes`
--

CREATE TABLE IF NOT EXISTS `oauth_auth_code_scopes` (
  `id` int(10) unsigned NOT NULL,
  `auth_code_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `scope_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_code_scopes_auth_code_id_index` (`auth_code_id`),
  KEY `oauth_auth_code_scopes_scope_id_index` (`scope_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE IF NOT EXISTS `oauth_clients` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `secret` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `oauth_clients_id_secret_unique` (`id`,`secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `secret`, `name`, `created_at`, `updated_at`) VALUES
('f1b4fb110d66392d42ac58430596fc51', '337a856e05a0a104889c2cd72876fa5b', 'fakhri1804@gmail.com', '2016-02-16 17:00:00', '2016-02-16 17:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_client_endpoints`
--

CREATE TABLE IF NOT EXISTS `oauth_client_endpoints` (
  `id` int(10) unsigned NOT NULL,
  `client_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `redirect_uri` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_client_grants`
--

CREATE TABLE IF NOT EXISTS `oauth_client_grants` (
  `id` int(10) unsigned NOT NULL,
  `client_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `grant_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_client_scopes`
--

CREATE TABLE IF NOT EXISTS `oauth_client_scopes` (
  `id` int(10) unsigned NOT NULL,
  `client_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `scope_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_grants`
--

CREATE TABLE IF NOT EXISTS `oauth_grants` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_grant_scopes`
--

CREATE TABLE IF NOT EXISTS `oauth_grant_scopes` (
  `id` int(10) unsigned NOT NULL,
  `grant_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `scope_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE IF NOT EXISTS `oauth_refresh_tokens` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `access_token_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `expire_time` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_scopes`
--

CREATE TABLE IF NOT EXISTS `oauth_scopes` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_sessions`
--

CREATE TABLE IF NOT EXISTS `oauth_sessions` (
  `id` int(10) unsigned NOT NULL,
  `client_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `owner_type` enum('client','user') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'user',
  `owner_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `client_redirect_uri` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_session_scopes`
--

CREATE TABLE IF NOT EXISTS `oauth_session_scopes` (
  `id` int(10) unsigned NOT NULL,
  `session_id` int(10) unsigned NOT NULL,
  `scope_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `description` text,
  `price` int(10) DEFAULT NULL,
  `price_disc` int(10) DEFAULT NULL,
  `price_reseller` varchar(10) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `brand` int(11) DEFAULT NULL,
  `code` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=58 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `description`, `price`, `price_disc`, `price_reseller`, `created_date`, `brand`, `code`) VALUES
(2, 'Jumpsuit', '*Recommended\r\n*Salah satu produk best seller\r\n*material cotton\r\n', 58500, 45000, '04', '2016-02-19 02:07:58', 1, 'ci002'),
(3, 'Jumpsuit', 'Best seller\r\nRecommended banget', 58500, 45000, '04', '2016-02-19 02:36:44', 1, 'ci003'),
(4, 'Jumpsuit', 'Best seller\r\nRecommended banget\r\n\r\nTosca sold', 58500, 45000, '04', '2016-02-19 02:58:46', 1, 'ci004'),
(5, 'Jumpsuit', 'Recommended\r\nCotton\r\nBest seller', 58500, 45000, '04', '2016-02-19 05:27:16', 1, 'ci005'),
(6, 'Jumpsuit', 'Cotton\r\nBest seller', 58500, 45000, '04', '2016-02-19 05:29:15', 1, 'ci006'),
(7, 'Jumpsuit', 'Best seller', 58500, 45000, '04', '2016-02-19 06:01:58', 1, 'ci007'),
(8, 'Jumpsuit', 'Best seller', 58500, 45000, '04', '2016-02-19 06:03:23', 1, 'ci008'),
(9, 'Jumpsuit', 'Best seller\r\nMatterial cotton', 58500, 45000, '04', '2016-02-19 06:04:43', 1, 'ci009'),
(10, 'Jumpsuit', 'Best seller\r\nMatterial cotton', 58500, 45000, '04', '2016-02-19 07:28:46', 1, 'ci010'),
(11, 'Jumpsuit', 'Matterial cotton stretch\r\n', 52000, 40000, '53', '2016-02-19 07:29:44', 1, 'ci011'),
(12, 'Dress', 'Nyaman banget dipakai si kecil', 39000, 30000, '5,72', '2016-02-19 08:28:35', 5, 'Ze001'),
(13, 'Dress', 'Nyaman bgt dipakai si kecil', 39000, 30000, '5,72', '2016-02-19 08:29:51', 5, 'Ze002'),
(14, 'Dress', 'Nyaman banget dipakai si kecil', 39000, 30000, '5,72', '2016-02-19 08:31:10', 5, 'Ze003'),
(15, 'Jumpsuit', 'Matterial cotton', 52000, 40000, '53', '2016-02-19 15:40:22', 1, 'ci012'),
(16, 'Dress', 'Nyaman banget dipakai sikecil', 39000, 30000, '5,72', '2016-02-19 15:43:36', 5, 'Ze004'),
(17, 'Dress', 'Nyaman bgt dipakai si kecil', 39000, 30000, '5,72', '2016-02-19 16:08:05', 5, 'Ze005'),
(18, 'Dress', 'Nyaman banget dipakai si kecil', 39000, 30000, '5,72', '2016-02-19 16:10:33', 5, 'Ze006'),
(19, 'Dress', 'Nyamaaaaan bgt dipakai sikecil', 39000, 30000, '5,72', '2016-02-19 16:11:49', 5, 'Ze007'),
(20, 'Dress', 'Nyaman banget dipakai sikecil', 39000, 30000, '5,72', '2016-02-19 16:13:17', 5, 'Ze008'),
(21, 'Dress', 'Nyamaaaaan bgt dipakai sikecil', 39000, 30000, '5,72', '2016-02-19 16:14:53', 5, 'Ze009'),
(22, 'Dress', 'Nyaman bgt dipakai si kecil', 39000, 30000, '5,72', '2016-02-19 18:56:18', 5, 'Ze010'),
(23, 'Dress', 'Nyaman bgt dipakai si kecil', 39000, 30000, '5,72', '2016-02-19 22:51:11', 5, 'Ze011'),
(24, 'Dress', 'Nyaman bgt dipakai si kecil', 39000, 30000, '5,72', '2016-02-19 23:02:49', 5, 'Ze012'),
(25, 'Dress', 'Material cotton,lembut,halus,ringan\r\nNyaman banget dipakai si kecil', 39000, 30000, '5,72', '2016-02-19 23:12:45', 5, 'Ze013'),
(26, 'Dress', 'Bahan cotton,lembut,ringan\r\nNyaman bangeeeet dipakai sikecil', 39000, 30000, '5,72', '2016-02-19 23:29:54', 5, 'Ze014'),
(27, 'Dress', 'Matterial cotton,,lembut,halus,ringan\r\nNyaman banget dipakai sikecil', 39000, 30000, '5,72', '2016-02-19 23:31:31', 5, 'Ze015'),
(28, 'Dress', 'Bahan cotton,lembut\r\nNyaman bgt dipakai sikecil', 39000, 30000, '5,72', '2016-02-19 23:35:52', 5, 'Ze016'),
(29, 'Dress', 'Bahan cotton,halus,lembut\r\nNyaman banget dipakai si kecil', 39000, 30000, '5,72', '2016-02-19 23:38:06', 5, 'Ze017'),
(30, 'Dress', 'Cotton,lembut,nyaman bgt dipakai si kecil', 39000, 30000, '5,72', '2016-02-20 02:17:44', 5, 'Ze018'),
(31, 'Dress', 'Cotton..nyaman bgt dipakai si kecil', 39000, 30000, '5,72', '2016-02-20 02:48:58', 5, 'Ze019'),
(32, 'Tee', '', 42250, 32500, '03', '2016-02-21 14:18:03', 20, 'Bv001'),
(34, 'Tee', '', 42250, 32500, '03', '2016-02-21 14:20:24', 20, ''),
(35, 'Tee', '', 42250, 32500, '03', '2016-02-21 14:21:23', 20, 'Bv002'),
(36, 'Tee', '', 42250, 32500, '03', '2016-02-21 14:22:55', 20, 'Bv003'),
(37, 'Tee', '', 42250, 32500, '03', '2016-02-21 14:24:25', 20, 'Bv004'),
(38, 'Tee', '', 42250, 32500, '03', '2016-02-21 14:25:19', 20, 'Bv005'),
(39, 'Tee', '', 42250, 32500, '03', '2016-02-21 14:26:20', 20, 'Bv006'),
(40, 'Tee', '', 42250, 32500, '03', '2016-02-21 14:34:04', 20, 'Bv007'),
(41, 'Tee', '', 42250, 32500, '03', '2016-02-21 14:35:42', 20, 'Bv008'),
(42, 'Tee', '', 42250, 32500, '03', '2016-02-21 14:36:53', 20, 'Bv009'),
(43, 'Tee', '', 42250, 32500, '03', '2016-02-21 14:37:36', 20, ''),
(44, 'Tee', '', 52000, 40000, '53', '2016-02-21 14:38:48', 20, 'Bv010'),
(45, 'Tee', '', 52000, 40000, '53', '2016-02-21 14:39:46', 20, 'Bv011'),
(46, 'Tee', '', 52000, 40000, '53', '2016-02-21 14:40:55', 20, 'Bv012'),
(47, 'Tee', '', 52000, 40000, '53', '2016-02-21 19:03:31', 20, 'Bv013'),
(48, 'Tee', '', 52000, 40000, '53', '2016-02-21 19:04:45', 20, 'Bv014'),
(49, 'Tee', '', 42250, 32500, '03', '2016-02-21 19:07:57', 20, 'Bv015'),
(50, 'Tee', '', 42250, 32500, '03', '2016-02-21 19:17:49', 20, 'Bv016'),
(51, 'Tee', '', 42250, 32500, '03', '2016-02-21 19:26:55', 20, 'Bv017'),
(52, 'Tee', '', 42250, 32500, '03', '2016-02-21 19:29:17', 20, 'Bv018'),
(53, 'Tee', '', 42250, 32500, '03', '2016-02-21 19:31:02', 20, 'Bv019'),
(54, 'Tee', '', 42250, 32500, '03', '2016-02-21 19:33:48', 20, 'Bv020'),
(55, 'Tee', '', 42250, 32500, '03', '2016-02-21 19:34:45', 20, 'Bv021'),
(56, 'Tee', '', 42250, 32500, '03', '2016-02-21 19:41:41', 20, 'Bv022'),
(57, 'TEST CIRCO', 'DESC', 3250, 2500, 'TE', '2016-02-22 19:18:56', 1, 'ci013');

-- --------------------------------------------------------

--
-- Table structure for table `product_age`
--

CREATE TABLE IF NOT EXISTS `product_age` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `age` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_age`
--

INSERT INTO `product_age` (`id`, `product_id`, `age`) VALUES
(8, 2, 1),
(9, 3, 1),
(10, 4, 1),
(11, 5, 2),
(12, 6, 2),
(13, 7, 2),
(14, 8, 2),
(15, 9, 2),
(16, 10, 2),
(17, 11, 2),
(18, 12, 2),
(19, 13, 2),
(20, 14, 2),
(22, 16, 2),
(23, 17, 2),
(24, 18, 2),
(25, 19, 2),
(26, 20, 2),
(27, 21, 2),
(28, 22, 2),
(29, 23, 2),
(30, 24, 2),
(31, 25, 2),
(32, 26, 2),
(33, 27, 2),
(34, 28, 2),
(35, 29, 2),
(36, 30, 2),
(37, 31, 2),
(38, 32, 2),
(39, 33, 2),
(40, 34, 2),
(41, 35, 2),
(42, 36, 2),
(43, 37, 2),
(44, 38, 2),
(45, 39, 2),
(46, 40, 2),
(47, 41, 2),
(48, 42, 2),
(49, 43, 2),
(50, 44, 4),
(52, 46, 2),
(54, 48, 4),
(55, 49, 1),
(56, 50, 2),
(57, 51, 2),
(58, 52, 2),
(59, 53, 2),
(60, 54, 1),
(61, 55, 1),
(62, 56, 1),
(63, 57, 3),
(64, 57, 2),
(0, 0, 4),
(0, 0, 3),
(0, 0, 3),
(0, 0, 1),
(0, 0, 2),
(0, 0, 2),
(0, 57, 4),
(0, 57, 3),
(0, 47, 0),
(0, 15, 2),
(0, 45, 0),
(0, 57, 4),
(0, 57, 3),
(0, 57, 2);

-- --------------------------------------------------------

--
-- Table structure for table `product_brand`
--

CREATE TABLE IF NOT EXISTS `product_brand` (
  `id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `code` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_brand`
--

INSERT INTO `product_brand` (`id`, `name`, `code`) VALUES
(1, 'circo', 'ci'),
(2, 'oshkosh', 'os'),
(3, 'cherokee', 'ch'),
(4, 'carter', 'ca'),
(5, 'Zeezabutik', 'Ze'),
(6, 'No brand', 'No'),
(7, 'Oldnavy', 'On'),
(8, 'Chameleon', 'Ch'),
(9, 'Gap', 'Ga'),
(10, 'Place', 'Pl'),
(11, 'Next', 'Ne'),
(12, 'Puma', 'Pu'),
(13, 'Adidas', 'Ad'),
(14, 'Cherokee', 'Ch'),
(15, 'Dmc', 'Dm'),
(16, 'Hipobaby', 'Hi'),
(17, 'Max', 'Ma'),
(18, 'Fredferry', 'Fr'),
(19, 'Arizona', 'Ar'),
(20, 'Baby victory', 'Bv');

-- --------------------------------------------------------

--
-- Table structure for table `product_type`
--

CREATE TABLE IF NOT EXISTS `product_type` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_type`
--

INSERT INTO `product_type` (`id`, `product_id`, `type`) VALUES
(14, 2, 2),
(15, 3, 2),
(16, 4, 2),
(17, 5, 10),
(18, 6, 10),
(19, 7, 10),
(20, 8, 10),
(21, 9, 10),
(22, 10, 10),
(23, 11, 10),
(24, 12, 2),
(25, 13, 2),
(26, 14, 2),
(28, 16, 2),
(29, 17, 10),
(30, 18, 10),
(31, 19, 10),
(32, 20, 10),
(33, 21, 10),
(34, 22, 2),
(35, 23, 10),
(36, 24, 10),
(37, 25, 10),
(38, 26, 10),
(39, 27, 10),
(40, 28, 10),
(41, 29, 10),
(42, 30, 10),
(43, 31, 10),
(44, 32, 16),
(45, 33, 0),
(46, 34, 16),
(47, 35, 16),
(48, 36, 16),
(49, 37, 16),
(50, 38, 16),
(51, 39, 0),
(52, 40, 16),
(53, 41, 16),
(54, 42, 16),
(55, 43, 16),
(56, 44, 16),
(58, 46, 16),
(60, 48, 16),
(61, 49, 2),
(62, 50, 6),
(63, 51, 6),
(64, 52, 6),
(65, 53, 6),
(66, 54, 2),
(67, 55, 2),
(68, 56, 2),
(69, 57, 3),
(70, 57, 5),
(71, 57, 8),
(72, 57, 15),
(0, 0, 2),
(0, 0, 5),
(0, 0, 7),
(0, 0, 14),
(0, 0, 2),
(0, 0, 5),
(0, 0, 7),
(0, 0, 5),
(0, 0, 8),
(0, 0, 5),
(0, 0, 8),
(0, 57, 3),
(0, 57, 2),
(0, 57, 5),
(0, 47, 0),
(0, 15, 2),
(0, 45, 0),
(0, 57, 2),
(0, 57, 5),
(0, 57, 7),
(0, 57, 15),
(0, 57, 16),
(0, 57, 17);

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE IF NOT EXISTS `type` (
  `id_type` int(11) NOT NULL,
  `id_category` int(11) NOT NULL,
  `rank` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`id_type`, `id_category`, `rank`, `name`) VALUES
(1, 1, 0, 'headband'),
(2, 1, 1, 'Dress,jumpsuit'),
(3, 1, 2, 'prewalker'),
(4, 2, 0, 'Baju'),
(5, 2, 1, 'Prewalker'),
(6, 3, 0, 'Atasan'),
(7, 3, 1, 'Rok & Celana'),
(8, 3, 2, 'Jaket & Rompi'),
(9, 3, 3, 'Piyama'),
(10, 3, 4, 'Dress,jumpsuit,overall'),
(11, 3, 5, 'Baju Muslim'),
(12, 3, 6, 'Aksesoris'),
(13, 4, 0, 'Kemeja'),
(14, 4, 1, 'Polo Shirt'),
(15, 4, 2, 'Jaket & Rompi'),
(16, 4, 3, 'Baju'),
(17, 4, 4, 'Piyama'),
(18, 4, 5, 'Celana'),
(19, 4, 6, 'Aksesoris'),
(20, 1, 0, 'Setelan'),
(21, 1, 0, 'Celana,rok');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(3) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(60) NOT NULL,
  `remember_token` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'fakhri1804@gmail.com', 'fakhri1804@gmail.com', '25d55ad283aa400af464c76d713c07ad', NULL, NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
