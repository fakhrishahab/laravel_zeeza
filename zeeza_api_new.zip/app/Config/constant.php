<?php

return array(
		'SITE_PATH' => 'http://localhost/zeeza_api/'
	);