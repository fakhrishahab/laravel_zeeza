<?php

return array(
		'SITE_PATH' => 'http://localhost/zeeza_api/',
		'CLIENT_ID' => 'f1b4fb110d66392d42ac58430596fc51',
		'CLIENT_SECRET' => '337a856e05a0a104889c2cd72876fa5b' 
	);